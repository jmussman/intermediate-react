import "./styles.css";
import { useRef, useEffect } from 'react';
import Admin from './components/admin/admin';
import Home from "./components/home/home";
import Employees from "./components/employees/employees";
import Login from './components/login/login';
import Register from "./components/register/register";
import Enterweight from './components/enterweight/enterweight'
import { Route, Routes, useLocation } from "react-router-dom";
import ProtectedAdminRoute from './components/ProtectedAdminRoute';
import AdminLogin from './components/adminlogin/adminlogin'

function AppRoutes() {

  const focusRef = useRef(null);
  const currentLocation = useLocation();

  useEffect(() => {
    if (currentLocation.pathname === '/login') {
      focusRef.current?.focus()
    }
  }, [currentLocation.pathname]);

  return (
    <>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/employees' element={<Employees />} />
        <Route path='/register' element={<Register />} />
        <Route path='/enterweight' element={<Enterweight />} />
        <Route path='/login' element={<Login focusRef={focusRef} />} />
        <Route path='/admin' element={<ProtectedAdminRoute><Admin /></ProtectedAdminRoute>} />
        <Route path='/admin-login' element={<AdminLogin />} />
      </Routes>
    </>
  )
};
//
export default AppRoutes;