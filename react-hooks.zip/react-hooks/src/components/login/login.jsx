import Header from "../wrapper/header";
import Container from "./container";
import Footer from "../wrapper/footer";
//
function Login({ focusRef }){
  return (
    <div>
      <Header />
      <Container focusRef={focusRef} />
      <Footer />
    </div>
  );
};
//
export default Login;