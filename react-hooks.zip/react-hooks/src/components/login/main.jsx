import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";

import { AuthContext } from '../AuthContext'

//


//    this.handleSubmit = this.handleSubmit.bind(this); 
//    this.handleFieldChange = this.handleFieldChange.bind(this);
//  };
//


function Main({ focusRef }) {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginStatus, setLoginStatus] = useState('')
  const navigate = useNavigate();

  const { login } = useContext(AuthContext);

  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === 'username') {
      setUsername(value);
    }
    if (name === 'password') {
      setPassword(value)
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:3030/employees')
    .then(response => {
      return response.json()
    })
    .then(users => {
      const found = users.find(
        user => user.username === username && user.password === password
      );
      if (found) {
        login(found);
        console.log(`found: ${JSON.stringify(found)}`);
        setLoginStatus('');
        navigate('/');
      } else {
        setLoginStatus('Invalid username or password')
      }
    })
    .catch(err => {
      console.log("An error occured! " + err.message);
    });
  };

  return (
    <main>
      <h2>Login for the competition</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Name:
            <input type="text" name="username" value={username} onChange={handleFieldChange} ref={focusRef} />
          </label>
        </div>
        <div>
          <label>
            Password:
            <input type="password" name="password" onChange={handleFieldChange} />
          </label>
        </div>
        <div>
          <input type="submit" value="Submit" />
        </div>
      </form>
      { loginStatus && <p>{loginStatus}</p>}
    </main>
  );
};

export default Main;
