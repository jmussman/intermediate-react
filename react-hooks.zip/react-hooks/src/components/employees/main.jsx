import { useEffect, useState, useMemo } from "react";

function Main(props) {

  const [allEmployees, setAllEmployees] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3030/employees')
    .then(data => data.json())
    .then(resolvedData => setAllEmployees(resolvedData))
    .catch(error => {
      console.error('Error fetching employees +', error.message);
    })
  }, []);

  const sortedEmployees = useMemo(() => {
    
    return [...allEmployees].sort((a, b) => a.username.localeCompare(b.username))
    }, [allEmployees]);

  return (
    <main>
      <h2>Employee List - {props.message}</h2>
      {
        sortedEmployees.map((employee, i) =>
        (<div key={i}>
          {employee.username}&nbsp;
          {employee.password}
        </div>)
        )
      }
    </main>
  )
};
//
export default Main;
