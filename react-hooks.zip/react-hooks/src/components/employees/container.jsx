
import Main from "./main";
import Aside from "../wrapper/aside";
//
function Container(){
  return (
    <div id="container">
      <Main message="Hello, world!" name="Employees" />
      <Aside />
    </div>
  )
};
//
export default Container;
