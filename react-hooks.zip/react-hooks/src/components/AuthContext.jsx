import { createContext, useState } from "react";

const AuthContext = createContext();

function AuthProvider(props) {

    const [user, setUser] = useState(null);

    const login = userData => {
        setUser(userData);
    }

    const logout = () => {
        setUser(null);
    }

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            {props.children}
        </AuthContext.Provider>
    )
}

export { AuthContext, AuthProvider }