function Main(){
  return (
    <main>
      <h2>This is the admin panel</h2>
    </main>
  )
};
//
export default Main;
