import Header from "../wrapper/header";
import Container from "./container";
import Footer from "../wrapper/footer";
//
function AdminLogin({ focusRef }){
  return (
    <div>
      <Header />
      <Container focusRef={focusRef} />
      <Footer />
    </div>
  );
};
//
export default AdminLogin;