
import Main from "./main";
import Aside from "../wrapper/aside";
//
function Container({ focusRef }){
  return (
    <div id="container">
      <Main focusRef={focusRef} />
      <Aside />
    </div>
  )
};
//
export default Container;
